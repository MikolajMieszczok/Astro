import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
import io
from SciServer import SkyServer
from SciServer import Authentication

username = "TheOabringer"
password = "JamnikLover2137!"
# ----------------------------------------------------------------
# SAFE CUTOUT FETCHER
# ----------------------------------------------------------------
def get_sciserver_image(ra, dec, width, height, scale, dataRelease="DR13"):
    """
    Returns a proper NumPy RGB array regardless of what SciServer returns:
    - Already-decoded ndarray
    - Grayscale ndarray
    - Flat pixel buffer
    - JPEG bytes
    - Or detects an error string
    """
    img = SkyServer.getJpegImgCutout(
        ra=ra,
        dec=dec,
        width=width,
        height=height,
        scale=scale,
        dataRelease=dataRelease
    )

    if isinstance(img, np.ndarray):

        # Full RGB (H, W, 3)
        if img.ndim == 3 and img.shape[2] == 3:
            return img

        # Grayscale (H, W)
        if img.ndim == 2:
            return np.stack([img] * 3, axis=-1)

        # Flat buffer (your case)
        if img.ndim == 1:
            try:
                arr = img.reshape((height, width))
                return np.stack([arr] * 3, axis=-1)
            except Exception as e:
                print("Could not reshape buffer:", e, "shape=", img.shape)
                return None

    # ------------------------------------------------------------
    # CASE 2 — JPEG bytes returned (rare)
    # ------------------------------------------------------------
    if isinstance(img, (bytes, bytearray)):
        try:
            pil_img = Image.open(io.BytesIO(img))
            return np.array(pil_img)
        except Exception as e:
            print("JPEG decode error:", e)
            return None

    # ------------------------------------------------------------
    # CASE 3 — Text error returned by server
    # ------------------------------------------------------------
    if isinstance(img, str):
        print("SciServer returned text/error:", img[:200])
        return None

    print("Unknown SciServer return:", type(img))
    return None


def main():
    ra = 30.670
    dec = -1.0234
    width = 300
    height = 300
    scale = 0.8
    img = get_sciserver_image(
        ra,
        dec,
        width,
        height,
        scale
    )

    if img is not None:
        plt.figure(figsize=(10,10))
        plt.imshow(img)
        plt.title("Sky Image for " + str(ra) + ", " + str(dec))
        plt.axis("off")
        plt.show()
    else:
        print("Failed to fetch image")

if __name__ == "__main__":
    main()